/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package character_stream_3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Student
 */
public class Lab5 {
    public static void main(String[] args) {
        InputStreamReader in = new InputStreamReader(System.in);
    BufferedReader input = new BufferedReader(in);
        System.out.print("Enter text: ");
        try {
            String s = input.readLine();
            System.out.println(s);
        } catch (IOException ex) {
            Logger.getLogger(Lab5.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    
    
}
